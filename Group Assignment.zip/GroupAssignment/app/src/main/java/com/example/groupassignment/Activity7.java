package com.example.groupassignment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;

public class Activity7 extends AppCompatActivity {

    private TextView textReaderType;
    private TextView textResult;
    private ImageView imageView;
    private Button buttonEdit, buttonDelete, buttonCancel;
    private String dataId;
    private AnalysedImage currentData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_7);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textReaderType = findViewById(R.id.textReaderType);
        textResult = findViewById(R.id.textResult);
        imageView = findViewById(R.id.imageViewActivity7);
        buttonEdit = findViewById(R.id.buttonEdit);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonCancel = findViewById(R.id.buttonCancel);

        dataId = getIntent().getStringExtra("DATA_ID");

        if (dataId != null) {
            DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("analysed_images").child(dataId);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    currentData = snapshot.getValue(AnalysedImage.class);
                    if (currentData != null) {
                        textReaderType.setText(currentData.readerType);
                        textResult.setText(currentData.resultText);
                        if (currentData.imagePath != null) {
                            File file = new File(currentData.imagePath);
                            if (file.exists()) {
                                imageView.setImageURI(Uri.fromFile(file));
                            } else {
                                imageView.setImageURI(Uri.parse(currentData.imagePath));
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        buttonEdit.setOnClickListener(v -> {
            if (currentData != null) {
                Intent intent = new Intent(Activity7.this, Activity5.class);
                intent.putExtra("DATA_ID", dataId);
                intent.putExtra("READER_TYPE", currentData.readerType);
                intent.putExtra("RESULT_TEXT", currentData.resultText);
                intent.putExtra("IMAGE_URI", currentData.imagePath);
                intent.putExtra("IS_NEW", false);
                startActivity(intent);
            }
        });

        buttonDelete.setOnClickListener(v -> {
            if (dataId != null) {
                FirebaseDatabase.getInstance().getReference("analysed_images").child(dataId).removeValue()
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(Activity7.this, "Deleted", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Activity7.this, Activity6.class);
                            startActivity(intent);
                            finish();
                        });
            }
        });

        buttonCancel.setOnClickListener(v -> {
            Intent intent = new Intent(Activity7.this, Activity6.class);
            startActivity(intent);
            finish();
        });
    }
}