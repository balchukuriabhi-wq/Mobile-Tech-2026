package com.example.groupassignment;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.graphics.Bitmap;
import java.util.Locale;
import java.util.UUID;

public class Activity2 extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;
    private TextView textViewTitle;
    private Button buttonEditResult;
    private Button buttonOpenCamera;
    private Button buttonLoadImage;
    private String readerMode;
    private String dataId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageView);
        textViewOutput = findViewById(R.id.activity2subheading);
        textViewTitle = findViewById(R.id.activity2title);
        buttonEditResult = findViewById(R.id.buttoneditresult);
        buttonOpenCamera = findViewById(R.id.buttonopencamera);
        buttonLoadImage = findViewById(R.id.buttonloadimage);

        readerMode = getIntent().getStringExtra("READER_MODE");
        if (readerMode == null) readerMode = "Text Reader";

        updateUIBasedOnMode();

        buttonOpenCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCamera(v);
            }
        });
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadImage(v);
            }
        });
        buttonEditResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editResult(v);
            }
        });
    }

    private void updateUIBasedOnMode() {
        textViewTitle.setText("Get Image from Camera or Gallery");
        textViewOutput.setText("Tap OPEN CAMERA or LOAD IMAGE to get an image for analysis");
        buttonEditResult.setVisibility(View.GONE);

        int initialImageRes = getIntent().getIntExtra("INITIAL_IMAGE", R.mipmap.text_reader_foreground);
        imageView.setImageResource(initialImageRes);
    }

    public void openCamera(View view) {
        if (!checkPermission())
            return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From your Camera");
        imageFileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    if (result.getData() != null && result.getData().getData() != null) {
                        imageFileUri = result.getData().getData();
                    }

                    if (imageFileUri != null) {
                        imageView.setImageURI(imageFileUri);
                        textViewOutput.setText("");
                        InputImage image = null;
                        try {
                            image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (image != null) {
                            processImage(image);
                        }
                    }
                }
            });

    private void processImage(InputImage image) {
        textViewTitle.setText(readerMode);
        buttonEditResult.setVisibility(View.VISIBLE);

        switch (readerMode) {
            case "Barcode Reader":
                processBarcode(image);
                break;
            case "Content Reader":
                processContent(image);
                break;
            case "Text Reader":
            default:
                processText(image);
                break;
        }
    }

    private void processBarcode(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    textViewOutput.setText("");
                    String rawResult = "";
                    if (barcodes.isEmpty()) {
                        rawResult = "Barcode not found.";
                    } else {
                        int counter = 1;
                        for (Barcode barcode : barcodes) {
                            rawResult += counter + ". " + barcode.getRawValue() + "\n";
                            counter++;
                        }
                    }
                    textViewOutput.setText(rawResult);
                    saveToDatabaseInBackground(rawResult);
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processContent(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    textViewOutput.setText("");
                    if (labels.isEmpty()) {
                        textViewOutput.setText("Nothing found in the image");
                        return;
                    }
                    String rawResult = "";
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        rawResult += counter + ". " + label.getText() +
                                " (" + String.format(Locale.getDefault(), "%.1f", label.getConfidence() * 100.0f) + "% confidence)\n";
                        counter++;
                    }
                    textViewOutput.setText(rawResult);
                    saveToDatabaseInBackground(rawResult);
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processText(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    textViewOutput.setText("");
                    String resultText = visionText.getText();
                    if (resultText != null && !resultText.trim().isEmpty()) {
                        textViewOutput.setText(resultText);
                        saveToDatabaseInBackground(resultText);
                    } else {
                        textViewOutput.setText("No text found.");
                        saveToDatabaseInBackground("No text found.");
                    }
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void saveToDatabaseInBackground(String resultText) {
        if (imageFileUri == null) return;
        String savedPath = saveImageToInternalStorage(imageFileUri);
        if (savedPath == null) return;

        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("analysed_images");
        if (dataId == null) {
            dataId = myRef.push().getKey();
        }

        AnalysedImage data = new AnalysedImage(readerMode, resultText, savedPath);
        data.id = dataId;

        if (dataId != null) {
            myRef.child(dataId).setValue(data);
        }
    }

    private String saveImageToInternalStorage(Uri uri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            String fileName = "IMG_" + UUID.randomUUID().toString() + ".jpg";
            File file = new File(getFilesDir(), fileName);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void editResult(View view) {
        Intent intent = new Intent(Activity2.this, Activity5.class);
        intent.putExtra("READER_TYPE", readerMode);
        intent.putExtra("RESULT_TEXT", textViewOutput.getText().toString());
        if (imageFileUri != null) {
            intent.putExtra("IMAGE_URI", imageFileUri.toString());
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        intent.putExtra("IS_NEW", false);
        intent.putExtra("DATA_ID", dataId);
        startActivity(intent);
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }
}