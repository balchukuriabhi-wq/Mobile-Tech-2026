package com.example.groupassignment;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.List;

public class ImageListAdapter extends ArrayAdapter<AnalysedImage> {
    private Context context;
    private List<AnalysedImage> list;

    public ImageListAdapter(@NonNull Context context, List<AnalysedImage> list) {
        super(context, R.layout.list_item, list);
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        AnalysedImage currentItem = list.get(position);

        ImageView imageView = convertView.findViewById(R.id.itemImage);
        TextView textView = convertView.findViewById(R.id.itemText);
        LinearLayout layout = convertView.findViewById(R.id.listItemLayout);

        textView.setText(currentItem.resultText);
        
        if (currentItem.imagePath != null) {
            File file = new File(currentItem.imagePath);
            if (file.exists()) {
                imageView.setImageURI(Uri.fromFile(file));
            } else {
                // Try as URI if not a file path
                try {
                    imageView.setImageURI(Uri.parse(currentItem.imagePath));
                } catch (Exception e) {
                    imageView.setImageResource(android.R.drawable.ic_menu_gallery);
                }
            }
        }

        // background color (grey for odd items and white for even items)
        // position starts from 0, so odd items are position 1, 3, 5...
        if (position % 2 == 0) {
            layout.setBackgroundColor(Color.WHITE);
        } else {
            layout.setBackgroundColor(Color.LTGRAY);
        }

        return convertView;
    }
}