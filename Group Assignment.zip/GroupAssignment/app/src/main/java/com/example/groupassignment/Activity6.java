package com.example.groupassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    private ListView listView;
    private List<AnalysedImage> imageList;
    private ImageListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_6);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
        imageList = new ArrayList<>();
        adapter = new ImageListAdapter(this, imageList);
        listView.setAdapter(adapter);

        Button btnAdd = findViewById(R.id.buttonAdd);
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(Activity6.this, MainActivity.class);
            startActivity(intent);
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            AnalysedImage selectedItem = imageList.get(position);
            Intent intent = new Intent(Activity6.this, Activity7.class);
            intent.putExtra("DATA_ID", selectedItem.id);
            intent.putExtra("READER_TYPE", selectedItem.readerType);
            intent.putExtra("RESULT_TEXT", selectedItem.resultText);
            intent.putExtra("IMAGE_PATH", selectedItem.imagePath);
            startActivity(intent);
        });

        loadData();
    }

    private void loadData() {
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("analysed_images");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                imageList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    AnalysedImage item = dataSnapshot.getValue(AnalysedImage.class);
                    if (item != null) {
                        imageList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}