package com.example.groupassignment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

public class Activity5 extends AppCompatActivity {

    private EditText editReaderType;
    private EditText editResultText;
    private ImageView imageView;
    private Button buttonSave;
    private String imageUriString;
    private boolean isNew = true;
    private String dataId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_5);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.editReaderType).getRootView(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editReaderType = findViewById(R.id.editReaderType);
        editResultText = findViewById(R.id.editResultText);
        imageView = findViewById(R.id.imageViewActivity5);
        buttonSave = findViewById(R.id.buttonSave);

        Intent intent = getIntent();
        if (intent != null) {
            editReaderType.setText(intent.getStringExtra("READER_TYPE"));
            editResultText.setText(intent.getStringExtra("RESULT_TEXT"));
            imageUriString = intent.getStringExtra("IMAGE_URI");
            if (imageUriString != null) {
                imageView.setImageURI(Uri.parse(imageUriString));
            }
            isNew = intent.getBooleanExtra("IS_NEW", true);
            dataId = intent.getStringExtra("DATA_ID");
        }

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSaveClick(v);
            }
        });
    }

    public void onSaveClick(View v) {
        if (isNew) {
            saveNewData();
        } else {
            updateExistingData();
        }
    }

    private void saveNewData() {
        if (imageUriString == null) {
            Toast.makeText(this, "No image to save", Toast.LENGTH_SHORT).show();
            return;
        }

        String savedPath = saveImageToInternalStorage(Uri.parse(imageUriString));
        if (savedPath == null) {
            Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("analysed_images");
        String id = myRef.push().getKey();
        AnalysedImage data = new AnalysedImage(editReaderType.getText().toString(), editResultText.getText().toString(), savedPath);
        data.id = id;

        if (id != null) {
            myRef.child(id).setValue(data).addOnSuccessListener(aVoid -> {
                openActivity6();
            }).addOnFailureListener(e -> {
                Toast.makeText(Activity5.this, "Database Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            });
        }
    }

    private void updateExistingData() {
        if (dataId == null) return;
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("analysed_images").child(dataId);

        String currentPath = imageUriString;
        if (imageUriString != null && (imageUriString.startsWith("content://") || imageUriString.startsWith("file://"))) {
            String savedPath = saveImageToInternalStorage(Uri.parse(imageUriString));
            if (savedPath != null) {
                currentPath = savedPath;
            }
        }

        AnalysedImage data = new AnalysedImage(editReaderType.getText().toString(), editResultText.getText().toString(), currentPath);
        data.id = dataId;

        myRef.setValue(data).addOnSuccessListener(aVoid -> {
            openActivity6();
        }).addOnFailureListener(e -> {
            Toast.makeText(Activity5.this, "Database Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        });
    }

    private String saveImageToInternalStorage(Uri uri) {
        if (uri.getScheme() != null && !uri.getScheme().equals("content") && !uri.getScheme().equals("file")) {
            return uri.toString();
        }
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            String fileName = "IMG_" + UUID.randomUUID().toString() + ".jpg";
            File file = new File(getFilesDir(), fileName);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "IO Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return null;
        }
    }

    private void openActivity6() {
        Intent intent = new Intent(this, Activity6.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}