package com.example.groupassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView barcodeImg = findViewById(R.id.imageViewBarcode);
        barcodeImg.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity2.class);
            intent.putExtra("READER_MODE", "Barcode Reader");
            intent.putExtra("INITIAL_IMAGE", R.mipmap.barcode_reader_foreground);
            startActivity(intent);
        });

        ImageView contentImg = findViewById(R.id.imageViewContent);
        contentImg.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity2.class);
            intent.putExtra("READER_MODE", "Content Reader");
            intent.putExtra("INITIAL_IMAGE", R.mipmap.content_reader_foreground);
            startActivity(intent);
        });

        ImageView textImg = findViewById(R.id.imageViewText);
        textImg.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity2.class);
            intent.putExtra("READER_MODE", "Text Reader");
            intent.putExtra("INITIAL_IMAGE", R.mipmap.text_reader_foreground);
            startActivity(intent);
        });

        Button btnList = findViewById(R.id.buttonList);
        btnList.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(this, Class.forName("com.example.groupassignment.Activity6"));
                startActivity(intent);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });
    }
}