package com.example.groupassignment;

public class AnalysedImage {
    public String id;
    public String readerType;
    public String resultText;
    public String imagePath; // Local path to internal storage

    public AnalysedImage() {
        // Default constructor required for calls to DataSnapshot.getValue(AnalysedImage.class)
    }

    public AnalysedImage(String readerType, String resultText, String imagePath) {
        this.readerType = readerType;
        this.resultText = resultText;
        this.imagePath = imagePath;
    }
}